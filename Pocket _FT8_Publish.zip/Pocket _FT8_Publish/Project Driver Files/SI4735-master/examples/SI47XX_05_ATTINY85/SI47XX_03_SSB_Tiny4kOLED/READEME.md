# Under construction.....

__This circuit and sketch will use eeprom to read the SSB patchcontent.__
The sketch to save the SSB patch content in a eeprom can be found on SI47XX_TOOLS folder.



