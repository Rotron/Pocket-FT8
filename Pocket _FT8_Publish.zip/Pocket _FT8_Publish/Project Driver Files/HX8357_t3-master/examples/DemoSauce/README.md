# DemoSauce

State-of-the-art graphics for your TFT display.

Greetz to the Portland Dorkbot Cr3w!!!!

+ Programmed by [Zach Archer](http://controlzinc.com/) (@zkarcher)
+ Using hardware by [Thomas Hudson](http://thomashudson.org/) (@hydronics)

Usage:
  * Connect a microphone to MIC_PIN.
  * Connect TFT backlight to BACKLIGHT_PIN.

MIT license, all text above must be included in any redistribution
